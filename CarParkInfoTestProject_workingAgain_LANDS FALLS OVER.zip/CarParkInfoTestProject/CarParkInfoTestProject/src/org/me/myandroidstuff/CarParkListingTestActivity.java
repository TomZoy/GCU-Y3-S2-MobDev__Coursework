package org.me.myandroidstuff;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;

import android.app.Activity;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewSwitcher;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;



public class CarParkListingTestActivity extends Activity implements OnClickListener 
{

	//variables bound to GUI
	private Button backButton;
	//private TextView response;
	private TextView errorText;
	private TextView textViewTotalOccu;
	private TextView textViewTotalTotal;
	private TextView textViewTotalOccup;
	private TextView textViewS2Name;
	private TextView textViewS2Spaces;
	private TextView textViewS2Occup;
	private TextView textViewS2Status;
	
	private ViewSwitcher avw;
	
	//other variables
		private String sourceListingURL = "http://tomzoy.me/tmp/parking.xml";  
   //private String sourceListingURL = "http://open.glasgow.gov.uk/api/live/parking.php?type=xml";

    private ArrayList<carPark> carParkList = new ArrayList<carPark>(); // a list to store the carPark instances
	private String result; //string to hold xml data
	
    private boolean isDebugModeON = true;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) 
    {
    	
    	if (isDebugModeON) Log.w("Tom - report","appstart test");
    	
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        //set up viewSwitcher
        avw = (ViewSwitcher) findViewById(R.id.vwSwitch);
        
        // Get the View object on which to display the results

        errorText = (TextView)findViewById(R.id.errorText);
        
        textViewTotalOccu = (TextView)findViewById(R.id.textViewTotalOccu);
        textViewTotalTotal = (TextView)findViewById(R.id.textViewTotalTotal);
        textViewTotalOccup = (TextView)findViewById(R.id.textViewTotalOccup);
        
        textViewS2Name = (TextView)findViewById(R.id.Parkname);
        textViewS2Spaces = (TextView)findViewById(R.id.S2Spaces);
        textViewS2Occup = (TextView)findViewById(R.id.S2Occup);
        textViewS2Status = (TextView)findViewById(R.id.S2Status);
        
    	backButton= (Button) findViewById(R.id.s2backbutton);
        backButton.setOnClickListener(this);
        
        
        try
        {
        	// Get the data from the RSS stream as a string
        	if (isDebugModeON)Log.w("Tom - report","start reading data");
        	result =  sourceListingString(sourceListingURL);
        	
        	if (isDebugModeON)Log.w("Tom - report","point 1");

       	
        	// start parsing data
        	XmlPullParserFactory pullParserFactory;
    		try {
    			pullParserFactory = XmlPullParserFactory.newInstance();
    			XmlPullParser parser = pullParserFactory.newPullParser();

    		        parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
    		        
    		        parser.setInput(new StringReader ( result ));
    		        
    		        if (isDebugModeON)Log.w("Tom - report","before parser");
    	            
    		        parseXML(parser);
    		        if (isDebugModeON)Log.w("Tom - report","after parser");

    		} catch (XmlPullParserException e) {
    			e.printStackTrace();
    		} catch (IOException e) {
    			e.printStackTrace();
    		}

    		
    		if (isDebugModeON)Log.w("Tom - report","parser run with NO exception");
    		

    		if (isDebugModeON){
	        	Log.e("Tom - report -List","Total carparks: "+ Integer.toString(carParkList.size()));
	        	Log.e("Tom - report -List","Total Occupied Spaces: "+ Integer.toString(calc_global_OccupiedPlaces()));
	        	Log.e("Tom - report -List","Total Spaces: "+ Integer.toString(calc_global_TotalPlaces()));
        	Log.e("Tom - report -List","Total Occupancy: "+ Double.toString(carPark.calcOccupancy(calc_global_OccupiedPlaces(), calc_global_TotalPlaces())));
    		}
    		
        	//display data
        	displayData();

        	if (isDebugModeON)Log.e("Tom - report","program run DONE");

        }
        catch(IOException ae)
        {
        	//TODO make this a pop-up
        	// Handle error
        			//response.setText("Error");
        	
        	// Add error info to log for diagnostics

        	errorText.setText(ae.toString());
        } 
        
    } // End of onCreate
    
    
    
    private void displayData()
    {
    	//displaying "Global-Total" values
    	textViewTotalOccu.setText("Total Occupied Spaces: "+ Integer.toString(calc_global_OccupiedPlaces()));
    	textViewTotalTotal.setText("Total Spaces: "+ Integer.toString(calc_global_TotalPlaces()));
    	textViewTotalOccup.setText("Total Occupancy: "+ Double.toString(carPark.calcOccupancy(calc_global_OccupiedPlaces(), calc_global_TotalPlaces())));
    	
    	
    //constructing the listview

        final ListView listview = (ListView) findViewById(R.id.listview);
        final ArrayList<String> namelist = new ArrayList<String>();
        
        //building a name-list for the listview
        for (int i = 0; i < carParkList.size(); ++i) 
        {
        	namelist.add(carParkList.get(i).getName());
        }
 
        //assign the adapter
        final StableArrayAdapter adapter = new StableArrayAdapter(this,android.R.layout.simple_list_item_1,namelist);
        listview.setAdapter(adapter);

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {

        		public void onItemClick(AdapterView<?> parent, final View view, int position, long id) {
     
        				final String itemName = (String) parent.getItemAtPosition(position);
        				
        				//debug toast
        				Toast.makeText(getApplicationContext(), itemName+" selected", Toast.LENGTH_SHORT).show();
        				
        				//fill in the next screen and switch
        				genrateDetScreen(itemName);
        				
        				
        				//if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT)        				
        				avw.showNext();
        		}

 		});

	
    }
    
    // Method for filling in the details screen with the selected instance's values
    public void genrateDetScreen(String carpName)
    {
    	//get the selected carPark from the arraylist
    	int count = 0;
    	carPark selected = new carPark(); 	
    	selected = carParkList.get(0);
    	while (selected.getName()!=carpName)
    	{
    		count++;
    		selected = carParkList.get(count);
    	}
    	
    	//fill in text-fields
        textViewS2Name.setText(selected.getName());
        textViewS2Spaces.setText( Integer.toString(selected.getTakenSpaces())+" / "+Integer.toString(selected.getTotalSpaces()));
        textViewS2Occup.setText( Double.toString(selected.calcOccupancy())+"%");
        textViewS2Status.setText(selected.getStatus());

        if (isDebugModeON)Log.e("Tom - LOG",selected.getName());
    }
    
    
    // Method to handle the reading of the data from the XML stream
    private static String sourceListingString(String urlString)throws IOException
    {
	 	String result = "";
    	InputStream anInStream = null;
    	int response = -1;
    	URL url = new URL(urlString);
    	URLConnection conn = url.openConnection();
    	
    	Log.w("Tom - report","con 1");
    	
    	// Check that the connection can be opened
    	if (!(conn instanceof HttpURLConnection))
    	{
			Log.w("Tom - report","con 2");	
    		throw new IOException("Not an HTTP connection");
    	}
    	try
    	{
    		// Open connection
    		Log.w("Tom - report","con 3");
    		HttpURLConnection httpConn = (HttpURLConnection) conn;
    		Log.w("Tom - report","con 4");
    		httpConn.setAllowUserInteraction(false);
    		httpConn.setInstanceFollowRedirects(true);
    		httpConn.setRequestProperty("Accept-Charset", "UTF-8");
    		Log.w("Tom - report","con 5");
    		httpConn.setRequestMethod("GET");
    		Log.w("Tom - report","con 6");
    		httpConn.connect();
    		Log.w("Tom - report","con 7");
    		response = httpConn.getResponseCode();
    		Log.w("Tom - report","con 8");
    		// Check that connection is Ok
			boolean needLine = false;
			Log.w("Tom - report","con 9");
    		if (response == HttpURLConnection.HTTP_OK)
    		{
    			// Connection is Ok so open a reader 
    			anInStream = httpConn.getInputStream();
    			InputStreamReader in= new InputStreamReader(anInStream,"UTF-8");
    			BufferedReader bin= new BufferedReader(in);
    			
    			// Read in the data from the XML stream
    			String line = new String();

    			while (( (line = bin.readLine())) != null)
    			{
    				if (needLine == true)
    				result = result + "\r\n" + line;
    				needLine = true;
    			}
    		}
    	}
    	catch (Exception ex)
    	{
    			throw new IOException("Error connecting");
    	}
    	
    	// Return result as a string for further processing
    	return result;
    	
    }
    
      
    // Method for parsing the XML data to class instances
    private void parseXML(XmlPullParser parser) throws XmlPullParserException,IOException
	{

    	

    	if (isDebugModeON) Log.w("Tom - report","point 3");
        
        boolean isCarParkIdentityNext = false;
        boolean iscarParkStatusNext = false;
        boolean isoccupiedSpacesNext = false;
        boolean istotalCapacityNext = false;
        
        
    	 String Pname = null;
    	 int totalSpaces =0;
    	 int takenSpaces =0;
    	 String status = null;
        
        
        int eventType = parser.getEventType();
        while (eventType != XmlPullParser.END_DOCUMENT) {
         if(eventType == XmlPullParser.START_DOCUMENT) {
           
        	 if (isDebugModeON)  Log.w("Tom - report","Start document");
             
         } else if(eventType == XmlPullParser.START_TAG) {

        	 if (isDebugModeON) Log.w("Tom - report","Start tag: "+parser.getName());
            
             
             if (parser.getName().contains("carParkIdentity"))  
             {	
            	 isCarParkIdentityNext = true;  //trigger data filed "pull"
              } 
             
             
             else if (parser.getName().contains("carParkStatus"))  {	iscarParkStatusNext = true;  } //trigger data filed "pull"
             else if (parser.getName().contains("occupiedSpaces"))  {	isoccupiedSpacesNext = true;  } //trigger data filed "pull"
             else if (parser.getName().contains("totalCapacity"))  {	istotalCapacityNext = true;  }; //trigger data filed "pull"
             
  
         } else if(eventType == XmlPullParser.END_TAG) {

        	 if (isDebugModeON)  Log.w("Tom - report","End tag: "+parser.getName());
             
         } else if(eventType == XmlPullParser.TEXT) {

        	 if (isDebugModeON) Log.w("Tom - report","data: "+parser.getText());
             

            	
             if (isCarParkIdentityNext == true) 
        	 {
        	 	Log.e("Tom - report","the stuff that I need:"+parser.getText());
        	 	Pname = parser.getText();
        	 	isCarParkIdentityNext = false;
        	 }
            	 
        	 else if (iscarParkStatusNext == true) 
        	 {
        	 	Log.e("Tom - report","the stuff that I need:"+parser.getText());
        	 	status = parser.getText();     	 	
        	 	iscarParkStatusNext = false;
        	 } 
            	 
        	 else if (isoccupiedSpacesNext == true) 
        	 {
        	 	Log.e("Tom - report","the stuff that I need:"+parser.getText());
        	 	takenSpaces = Integer.parseInt(parser.getText());
        	 	isoccupiedSpacesNext = false;
        	 }
        	 
        	 else if (istotalCapacityNext == true) 
        	 {
        	 	Log.e("Tom - report","the stuff that I need:"+parser.getText());
        	 	totalSpaces = Integer.parseInt(parser.getText());
        	 	istotalCapacityNext = false;
        	 	
        	 	// construct new object
        	 	carPark currentCarPark;
        	 	currentCarPark = new carPark();
        	 	currentCarPark.setName(Pname);
        	 		currentCarPark.trimName();
        	 	currentCarPark.setStatus(status);
        	 	currentCarPark.setTakenSpaces(takenSpaces);
        	 	currentCarPark.setTotalSpaces(totalSpaces);
        	 	carParkList.add(currentCarPark);
        	 	
        	 	if (isDebugModeON)	Log.e("Tom - report-names","from OBJECT: "+currentCarPark.getName());
        	 	if (isDebugModeON)	Log.e("Tom - report-occu","occu: "+currentCarPark.calcOccupancy());
        	 };	
 	 
         }
         eventType = parser.next();
         if (isDebugModeON)  Log.i("Tom - report","jumpedToNext");
        }
 
        
	}
    
  
    //Method for calculating global_OccupiedPlaces
    private int calc_global_OccupiedPlaces()
    {
    	int count = 0;
    	
    	for(int i=0; i<carParkList.size();i++)
    	{
    		 count = count + carParkList.get(i).getTakenSpaces();  		
    	}
    	
    	return count;
    }
    
    //Method for calculating global_TotalPlaces
    private int calc_global_TotalPlaces()
    {
    	int count = 0;
    	
    	for(int i=0; i<carParkList.size();i++)
    	{
    		 count = count + carParkList.get(i).getTotalSpaces();		
    	}
    	
    	return count;
    }
     
    //Method to handle button clicks
	public void onClick(View arg0) 
	{
		if (arg0 == backButton)
		{
			avw.showPrevious();
		}
	}
    
} // End of Activity class