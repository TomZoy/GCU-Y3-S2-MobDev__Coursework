package org.me.myandroidstuff;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Iterator;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import java.io.StringReader;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;


public class CarParkListingTestActivity extends Activity 
{
	private TextView response;
	private TextView errorText;
	private String result;
    //private String sourceListingURL = "http://open.glasgow.gov.uk/api/live/parking.php?type=xml";
    //private String sourceListingURL = "http://tomzoy.me/tmp/tester_full.xml";
    private String sourceListingURL = "http://tomzoy.me/tmp/parking.xml";
    
	ArrayList<carPark> carParkList; // a list to store the carPark instances
	
	
    
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) 
    {
    	
    	Log.w("Tom - report","appstart test");
    	
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        // Get the TextView object on which to display the results
        response = (TextView)findViewById(R.id.urlResponse);
        try
        {
        	// Get the data from the RSS stream as a string
        	result =  sourceListingString(sourceListingURL);
        	String raw = result;
        	Log.w("Tom - report","point 1");
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	// Do some processing of the data to get the individual parts of the XML stream
        	// At some point put this processing into a separate thread of execution
        	
        	// Display the string in the TextView object just to demonstrate this capability
        	// This will need to be removed at some point
        	

        	XmlPullParserFactory pullParserFactory;
    		try {
    			pullParserFactory = XmlPullParserFactory.newInstance();
    			XmlPullParser parser = pullParserFactory.newPullParser();

    		        parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
    		        
    		        parser.setInput(new StringReader ( result ));
    	            Log.w("Tom - report","point 2");
    	            parseXML(parser);
    	            Log.w("Tom - report","point 20");

    		} catch (XmlPullParserException e) {

    			e.printStackTrace();
    		} catch (IOException e) {
    			//  Auto-generated catch block
    			e.printStackTrace();
    		}
        	
        	
    		
    		//---------------------------
    		

    		
    		Log.w("Tom - report","point 30");
    		
    		//-------------------------------
        	
        	response.setText(raw);
        	
    		Log.w("Tom - report","point 40 - DONE");
    		//Log.e("Tom - report",raw);
    		//response.setText(content);
        }
        catch(IOException ae)
        {
        	// Handle error
        	response.setText("Error");
        	// Add error info to log for diagnostics
        	errorText.setText(ae.toString());
        } 
        
    } // End of onCreate
    
    // Method to handle the reading of the data from the XML stream
    private static String sourceListingString(String urlString)throws IOException
    {
	 	String result = "";
    	InputStream anInStream = null;
    	int response = -1;
    	URL url = new URL(urlString);
    	URLConnection conn = url.openConnection();
    	
    	// Check that the connection can be opened
    	if (!(conn instanceof HttpURLConnection))
    			throw new IOException("Not an HTTP connection");
    	try
    	{
    		// Open connection
    		HttpURLConnection httpConn = (HttpURLConnection) conn;
    		httpConn.setAllowUserInteraction(false);
    		httpConn.setInstanceFollowRedirects(true);
    		httpConn.setRequestProperty("Accept-Charset", "UTF-8");
    		httpConn.setRequestMethod("GET");
    		httpConn.connect();
    		response = httpConn.getResponseCode();
    		// Check that connection is Ok
			boolean needLine = false;
    		if (response == HttpURLConnection.HTTP_OK)
    		{
    			// Connection is Ok so open a reader 
    			anInStream = httpConn.getInputStream();
    			InputStreamReader in= new InputStreamReader(anInStream,"UTF-8");
    			BufferedReader bin= new BufferedReader(in);
    			
    			// Read in the data from the XML stream
    			String line = new String();

    			while (( (line = bin.readLine())) != null)
    			{
    				if (needLine == true)
    				result = result + "\r\n" + line;
    				needLine = true;
    			}
    		}
    	}
    	catch (Exception ex)
    	{
    			throw new IOException("Error connecting");
    	}
    	
    	// Return result as a string for further processing
    	return result;
    	
    } // End of sourceListingString
    
    
    carPark currentCarPark;
    // ------------------------------------------
    
    private void parseXML(XmlPullParser parser) throws XmlPullParserException,IOException
	{

    	
    	
    	
     //   carPark currentCarPark = null;

        Log.w("Tom - report","point 3");
        
       // boolean needNext = false;
        boolean isCarParkIdentityNext = false;
        boolean iscarParkStatusNext = false;
        boolean isoccupiedSpacesNext = false;
        boolean istotalCapacityNext = false;
        
        
    	 String Pname = null;
    	 int totalSpaces =0;
    	 int takenSpaces =0;
    	 String status = null;
        
        
        int eventType = parser.getEventType();
        while (eventType != XmlPullParser.END_DOCUMENT) {
         if(eventType == XmlPullParser.START_DOCUMENT) {
           
             Log.w("Tom - report","Start document");
             
         } else if(eventType == XmlPullParser.START_TAG) {

             Log.w("Tom - report","Start tag: "+parser.getName());
            
             /*
             if (parser.getName().contains("carParkIdentity")) 
             	{
            	 	needNext = true; //trigger data filed "pull"
            	 	Log.w("Tom - report","needNext now true");
            	 } 
             */
             
             if (parser.getName().contains("carParkIdentity"))  
             {	
            	 isCarParkIdentityNext = true;  //trigger data filed "pull"
            	 
              } 
             
             
             else if (parser.getName().contains("carParkStatus"))  {	iscarParkStatusNext = true;  } //trigger data filed "pull"
             else if (parser.getName().contains("occupiedSpaces"))  {	isoccupiedSpacesNext = true;  } //trigger data filed "pull"
             else if (parser.getName().contains("totalCapacity"))  {	istotalCapacityNext = true;  }; //trigger data filed "pull"
             
             
             
         } else if(eventType == XmlPullParser.END_TAG) {

             Log.w("Tom - report","End tag: "+parser.getName());
             
         } else if(eventType == XmlPullParser.TEXT) {

             Log.w("Tom - report","data: "+parser.getText());
             

            	
             if (isCarParkIdentityNext == true) 
        	 {
        	 	Log.e("Tom - report","the stuff that I need:"+parser.getText());
        	 	Pname = parser.getText();
        	 	isCarParkIdentityNext = false;
        	 }
            	 
        	 else if (iscarParkStatusNext == true) 
        	 {
        	 	Log.e("Tom - report","the stuff that I need:"+parser.getText());
        	 	status = parser.getText();     	 	
        	 	iscarParkStatusNext = false;
        	 } 
            	 
        	 else if (isoccupiedSpacesNext == true) 
        	 {
        	 	Log.e("Tom - report","the stuff that I need:"+parser.getText());
        	 	takenSpaces = Integer.parseInt(parser.getText());
        	 	isoccupiedSpacesNext = false;
        	 }
        	 
        	 else if (istotalCapacityNext == true) 
        	 {
        	 	Log.e("Tom - report","the stuff that I need:"+parser.getText());
        	 	totalSpaces = Integer.parseInt(parser.getText());
        	 	istotalCapacityNext = false;
        	 	
        	 	// construct new object
        	 	currentCarPark = new carPark();
        	 	currentCarPark.setName(Pname);
        	 		currentCarPark.trimName();
        	 	currentCarPark.setStatus(status);
        	 	currentCarPark.setTakenSpaces(takenSpaces);
        	 	currentCarPark.setTotalSpaces(totalSpaces);
        	 //	carParkList.add(currentCarPark);
        	 	
        	 	
        	 	Log.e("Tom - report-names","from OBJECT: "+currentCarPark.getName());
        	 	Log.e("Tom - report-occu","occu: "+currentCarPark.calcOccupancy());
        	 };	
            	 
            	 
            	 
            	 
         }
         eventType = parser.next();
         Log.i("Tom - report","jumpedToNext");
        }
 
        
	}
    
  
    
} // End of Activity class