/**
 * 
 */
package org.me.myandroidstuff;

/**
 * @author TomZoy
 *
 */
public class carPark {

	/**
	 * 
	 */
	
	private String id;
	private String name;
	private int totalSpaces;
	private int takenSpaces;
	private String status;
	
	
	public carPark() {
		// TODO Auto-generated constructor stub
	}


	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}


	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}


	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}


	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}


	/**
	 * @return the totalSpaces
	 */
	public int getTotalSpaces() {
		return totalSpaces;
	}


	/**
	 * @param totalSpaces the totalSpaces to set
	 */
	public void setTotalSpaces(int totalSpaces) {
		this.totalSpaces = totalSpaces;
	}


	/**
	 * @return the takenSpaces
	 */
	public int getTakenSpaces() {
		return takenSpaces;
	}


	/**
	 * @param takenSpaces the takenSpaces to set
	 */
	public void setTakenSpaces(int takenSpaces) {
		this.takenSpaces = takenSpaces;
	}


	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}


	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

}
