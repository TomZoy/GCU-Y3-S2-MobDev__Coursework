package org.me.myandroidstuff;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

import android.util.Log;
import android.view.View;

import java.util.ArrayList;
import java.util.Iterator;

import android.app.Activity;
import android.os.Bundle;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;









import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;







//---------------------------------------------------

public class CarParkListingTestActivity extends Activity 
{

	
	
	//variables bound to GUI
	private TextView response;
	private TextView errorText;
	private TextView textViewTotalOccu;
	private TextView textViewTotalTotal;
	private TextView textViewTotalOccup;
	
	
	
	//other variables
    private String sourceListingURL = "http://tomzoy.me/tmp/parking.xml";
    //private String sourceListingURL = "http://open.glasgow.gov.uk/api/live/parking.php?type=xml";
    //private String sourceListingURL = "http://tomzoy.me/tmp/tester_full.xml";
    private ArrayList<carPark> carParkList = new ArrayList<carPark>(); // a list to store the carPark instances
	private String result;
    
	
	
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) 
    {
    	


    	
    	Log.w("Tom - report","appstart test");
    	
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        
        
        // Get the TextView object on which to display the results
        response = (TextView)findViewById(R.id.urlResponse);
        errorText = (TextView)findViewById(R.id.errorText);
        
        textViewTotalOccu = (TextView)findViewById(R.id.textViewTotalOccu);
        textViewTotalTotal = (TextView)findViewById(R.id.textViewTotalTotal);
        textViewTotalOccup = (TextView)findViewById(R.id.textViewTotalOccup);
        
        
        
        
        
        
        
        try
        {
        	// Get the data from the RSS stream as a string
        	result =  sourceListingString(sourceListingURL);
        	String raw = result;
        	Log.w("Tom - report","point 1");

        	
        	// Do some processing of the data to get the individual parts of the XML stream
        	// At some point put this processing into a separate thread of execution
        	
        	// Display the string in the TextView object just to demonstrate this capability
        	// This will need to be removed at some point
        	

        	XmlPullParserFactory pullParserFactory;
    		try {
    			pullParserFactory = XmlPullParserFactory.newInstance();
    			XmlPullParser parser = pullParserFactory.newPullParser();

    		        parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
    		        
    		        parser.setInput(new StringReader ( result ));
    	            Log.w("Tom - report","point 2");
    	            parseXML(parser);
    	            Log.w("Tom - report","point 20");

    		} catch (XmlPullParserException e) {

    			e.printStackTrace();
    		} catch (IOException e) {
    			//  Auto-generated catch block
    			e.printStackTrace();
    		}
        	
        	
    		
    		//---------------------------
    		

    		
    		Log.w("Tom - report","point 30");
    		
    		//-------------------------------
        	
        	//response.setText(raw);
        	
        	Log.e("Tom - report -List","Total carparks: "+ Integer.toString(carParkList.size()));
        	Log.e("Tom - report -List","Total Occupied Spaces: "+ Integer.toString(calc_global_OccupiedPlaces()));
        	Log.e("Tom - report -List","Total Spaces: "+ Integer.toString(calc_global_TotalPlaces()));
        	Log.e("Tom - report -List","Total Occupancy: "+ Double.toString(carPark.calcOccupancy(calc_global_OccupiedPlaces(), calc_global_TotalPlaces())));
        	
        	displayData();
        	

        	
    		Log.e("Tom - report","point 40 - Program DONE");
    		//Log.e("Tom - report",raw);

        }
        catch(IOException ae)
        {
        	// Handle error
        	response.setText("Error");
        	// Add error info to log for diagnostics
        	errorText.setText(ae.toString());
        } 
        
    } // End of onCreate
    
    
    
    private void displayData()
    {
    	textViewTotalOccu.setText("Total Occupied Spaces: "+ Integer.toString(calc_global_OccupiedPlaces()));
    	textViewTotalTotal.setText("Total Spaces: "+ Integer.toString(calc_global_TotalPlaces()));
    	textViewTotalOccup.setText("Total Occupancy: "+ Double.toString(carPark.calcOccupancy(calc_global_OccupiedPlaces(), calc_global_TotalPlaces())));
    	
    	
        //--- testing listview

        final ListView listview = (ListView) findViewById(R.id.listview);
        
 String[] values = new String[] { "Android", "iPhone", "WindowsMobile",
     "Blackberry", "WebOS", "Ubuntu", "Windows7", "Max OS X",
     "Linux", "OS/2", "Ubuntu", "Windows7", "Max OS X", "Linux",
     "OS/2", "Ubuntu", "Windows7", "Max OS X", "Linux", "OS/2",
     "Android", "iPhone", "WindowsMobile" };

 final ArrayList<String> list = new ArrayList<String>();
 for (int i = 0; i < values.length; ++i) {
   list.add(values[i]);
 }
 
 
 final ArrayList<String> namelist = new ArrayList<String>();
 for (int i = 0; i < carParkList.size(); ++i) {
	 namelist.add(carParkList.get(i).getName());
 }
 
 //final StableArrayAdapter adapter = new StableArrayAdapter(this,android.R.layout.simple_list_item_1, list);
 
 final StableArrayAdapter adapter = new StableArrayAdapter(this,android.R.layout.simple_list_item_1,namelist);
 
 listview.setAdapter(adapter);

/* listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {

  public void onItemClick(AdapterView<?> parent, final View view, int position, long id) {
     final String item = (String) parent.getItemAtPosition(position);
    /* view.animate().setDuration(2000).alpha(0).withEndAction(new Runnable() {
           public void run() {
             list.remove(item);
             adapter.notifyDataSetChanged();
             view.setAlpha(1);
           }
         });
   }

 });
*/
     
     
    // listview test over
    	
    	
    	
    	
    	
    	
    }
    
    
    
    
    
    // Method to handle the reading of the data from the XML stream
    private static String sourceListingString(String urlString)throws IOException
    {
	 	String result = "";
    	InputStream anInStream = null;
    	int response = -1;
    	URL url = new URL(urlString);
    	URLConnection conn = url.openConnection();
    	
    	// Check that the connection can be opened
    	if (!(conn instanceof HttpURLConnection))
    			throw new IOException("Not an HTTP connection");
    	try
    	{
    		// Open connection
    		HttpURLConnection httpConn = (HttpURLConnection) conn;
    		httpConn.setAllowUserInteraction(false);
    		httpConn.setInstanceFollowRedirects(true);
    		httpConn.setRequestProperty("Accept-Charset", "UTF-8");
    		httpConn.setRequestMethod("GET");
    		httpConn.connect();
    		response = httpConn.getResponseCode();
    		// Check that connection is Ok
			boolean needLine = false;
    		if (response == HttpURLConnection.HTTP_OK)
    		{
    			// Connection is Ok so open a reader 
    			anInStream = httpConn.getInputStream();
    			InputStreamReader in= new InputStreamReader(anInStream,"UTF-8");
    			BufferedReader bin= new BufferedReader(in);
    			
    			// Read in the data from the XML stream
    			String line = new String();

    			while (( (line = bin.readLine())) != null)
    			{
    				if (needLine == true)
    				result = result + "\r\n" + line;
    				needLine = true;
    			}
    		}
    	}
    	catch (Exception ex)
    	{
    			throw new IOException("Error connecting");
    	}
    	
    	// Return result as a string for further processing
    	return result;
    	
    } // End of sourceListingString
    
      
    // Method for parsing the XML data to class instances
    private void parseXML(XmlPullParser parser) throws XmlPullParserException,IOException
	{

    	
    	
    	
     //   carPark currentCarPark = null;

        Log.w("Tom - report","point 3");
        
       // boolean needNext = false;
        boolean isCarParkIdentityNext = false;
        boolean iscarParkStatusNext = false;
        boolean isoccupiedSpacesNext = false;
        boolean istotalCapacityNext = false;
        
        
    	 String Pname = null;
    	 int totalSpaces =0;
    	 int takenSpaces =0;
    	 String status = null;
        
        
        int eventType = parser.getEventType();
        while (eventType != XmlPullParser.END_DOCUMENT) {
         if(eventType == XmlPullParser.START_DOCUMENT) {
           
             Log.w("Tom - report","Start document");
             
         } else if(eventType == XmlPullParser.START_TAG) {

             Log.w("Tom - report","Start tag: "+parser.getName());
            
             /*
             if (parser.getName().contains("carParkIdentity")) 
             	{
            	 	needNext = true; //trigger data filed "pull"
            	 	Log.w("Tom - report","needNext now true");
            	 } 
             */
             
             if (parser.getName().contains("carParkIdentity"))  
             {	
            	 isCarParkIdentityNext = true;  //trigger data filed "pull"
            	 
              } 
             
             
             else if (parser.getName().contains("carParkStatus"))  {	iscarParkStatusNext = true;  } //trigger data filed "pull"
             else if (parser.getName().contains("occupiedSpaces"))  {	isoccupiedSpacesNext = true;  } //trigger data filed "pull"
             else if (parser.getName().contains("totalCapacity"))  {	istotalCapacityNext = true;  }; //trigger data filed "pull"
             
             
             
         } else if(eventType == XmlPullParser.END_TAG) {

             Log.w("Tom - report","End tag: "+parser.getName());
             
         } else if(eventType == XmlPullParser.TEXT) {

             Log.w("Tom - report","data: "+parser.getText());
             

            	
             if (isCarParkIdentityNext == true) 
        	 {
        	 	Log.e("Tom - report","the stuff that I need:"+parser.getText());
        	 	Pname = parser.getText();
        	 	isCarParkIdentityNext = false;
        	 }
            	 
        	 else if (iscarParkStatusNext == true) 
        	 {
        	 	Log.e("Tom - report","the stuff that I need:"+parser.getText());
        	 	status = parser.getText();     	 	
        	 	iscarParkStatusNext = false;
        	 } 
            	 
        	 else if (isoccupiedSpacesNext == true) 
        	 {
        	 	Log.e("Tom - report","the stuff that I need:"+parser.getText());
        	 	takenSpaces = Integer.parseInt(parser.getText());
        	 	isoccupiedSpacesNext = false;
        	 }
        	 
        	 else if (istotalCapacityNext == true) 
        	 {
        	 	Log.e("Tom - report","the stuff that I need:"+parser.getText());
        	 	totalSpaces = Integer.parseInt(parser.getText());
        	 	istotalCapacityNext = false;
        	 	
        	 	// construct new object
        	 	carPark currentCarPark;
        	 	currentCarPark = new carPark();
        	 	currentCarPark.setName(Pname);
        	 		currentCarPark.trimName();
        	 	currentCarPark.setStatus(status);
        	 	currentCarPark.setTakenSpaces(takenSpaces);
        	 	currentCarPark.setTotalSpaces(totalSpaces);
        	 	carParkList.add(currentCarPark);
        	 	
        	 	
        	 	Log.e("Tom - report-names","from OBJECT: "+currentCarPark.getName());
        	 	Log.e("Tom - report-occu","occu: "+currentCarPark.calcOccupancy());
        	 };	
            	 
            	 
            	 
            	 
         }
         eventType = parser.next();
         Log.i("Tom - report","jumpedToNext");
        }
 
        
	}
    
  
    //Method for callculating global_OccupiedPlaces
    private int calc_global_OccupiedPlaces()
    {
    	int count =0;
    	
    	for(int i=0; i<carParkList.size();i++)
    	{
    		 count = count + carParkList.get(i).getTakenSpaces();  		
    	}
    	
    	return count;
    }
    
    //Method for callculating global_TotalPlaces
    private int calc_global_TotalPlaces()
    {
    	int count =0;
    	
    	for(int i=0; i<carParkList.size();i++)
    	{
    		 count = count + carParkList.get(i).getTotalSpaces();		
    	}
    	
    	return count;
    }
    

    
    
    
} // End of Activity class