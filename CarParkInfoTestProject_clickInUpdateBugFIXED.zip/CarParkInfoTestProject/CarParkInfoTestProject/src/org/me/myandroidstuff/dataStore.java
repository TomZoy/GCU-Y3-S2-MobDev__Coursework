package org.me.myandroidstuff;

public class dataStore {

}
