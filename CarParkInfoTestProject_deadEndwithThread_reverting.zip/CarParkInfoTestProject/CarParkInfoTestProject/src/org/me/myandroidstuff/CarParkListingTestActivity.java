package org.me.myandroidstuff;


import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewSwitcher;





public class CarParkListingTestActivity extends Activity implements OnClickListener 
{

	//variables bound to GUI
	private Button backButton;
	private Button b1;
	private Button b2;	
	//private TextView response;
	private TextView errorText;
	private static TextView textViewTotalOccu;
	private static TextView textViewTotalTotal;
	private static TextView textViewTotalOccup;
	private static TextView textViewS2Name;
	private static TextView textViewS2Spaces;
	private static TextView textViewS2Occup;
	private static TextView textViewS2Status;
	private ImageView pieChart;
	private static ListView listview;
	
	private static ViewSwitcher avw;
    public static ArrayList<carPark> carParkList = new ArrayList<carPark>(); // a list to store the carPark instances

    private static boolean isDebugModeON = true;
    public static boolean isUpdated = false;
    public static boolean isAppRuning = true;
    public static boolean isOrientPort;
    private static Context context;
    
    static carPark selected = new carPark();
    
	//*private MyThreadTimer atimer;

	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) 
    {
    	
    	if (isDebugModeON) Log.w("Tom - report","appstart test");
    	
        super.onCreate(savedInstanceState);

        	//init containers
        	init();
        	
        	//read data in Async Task

        	if (!isUpdated)
        	{      
        		UpdData();

        	}
        	
        	//wait till the data gets initialised for the first time
        	while (!isUpdated)
        	{
        		SystemClock.sleep(70);
        	}

        	//display elements on the screen
    //    	displayData();
        	UpdateDispay();
        	
        	
        	if (isDebugModeON)Log.e("Tom - report","program run DONE");

        

        	
        	
    } // End of onCreate
    
    private void init()
    {
    	
        setContentView(R.layout.main);
        
        //set up viewSwitcher
        avw = (ViewSwitcher) findViewById(R.id.vwSwitch);
        
        // Get the View object on which to display the results
        
        //init listview
        listview = (ListView) findViewById(R.id.listview);

        //TODO sort this out
        errorText = (TextView)findViewById(R.id.author);
        
        textViewTotalOccu = (TextView)findViewById(R.id.textViewTotalOccu);
        textViewTotalTotal = (TextView)findViewById(R.id.textViewTotalTotal);
        textViewTotalOccup = (TextView)findViewById(R.id.textViewTotalOccup);
        
        textViewS2Name = (TextView)findViewById(R.id.Parkname);
        textViewS2Spaces = (TextView)findViewById(R.id.S2Spaces);
        textViewS2Occup = (TextView)findViewById(R.id.S2Occup);
        textViewS2Status = (TextView)findViewById(R.id.S2Status);
        
        pieChart = (ImageView)findViewById(R.id.PChart);
        
        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT)        				
        {
        	isOrientPort = true;
	        backButton= (Button) findViewById(R.id.s2backbutton);
	        backButton.setOnClickListener(this);
	        
	        b1= (Button) findViewById(R.id.b1);
	        b1.setOnClickListener(this);
	        b2= (Button) findViewById(R.id.b2);
	        b2.setOnClickListener(this);
        }
        
        CarParkListingTestActivity.context = getApplicationContext();
        
       //* atimer = new MyThreadTimer(mainHandler);
        
    	
    }
    

    //a method that displays the updated data on the screen
    void displayData()
    {
    	//displaying "Global-Total" values
    	textViewTotalOccu.setText("Total Occupied Spaces: "+ Integer.toString(calc_global_OccupiedPlaces()));
    	textViewTotalTotal.setText("Total Spaces: "+ Integer.toString(calc_global_TotalPlaces()));
    	textViewTotalOccup.setText("Total Occupancy: "+ Double.toString(carPark.calcOccupancy(calc_global_OccupiedPlaces(), calc_global_TotalPlaces())));
    	
    	
    //constructing the listview

        //*final ListView listview = (ListView) findViewById(R.id.listview);
        final ArrayList<String> namelist = new ArrayList<String>();
        
        //building a name-list for the listview
        for (int i = 0; i < carParkList.size(); ++i) 
        {
        	namelist.add(carParkList.get(i).getName());
        }
 
        //assign the adapter
        final StableArrayAdapter adapter = new StableArrayAdapter(this,android.R.layout.simple_list_item_1,namelist);
        listview.setAdapter(adapter);

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {

        		public void onItemClick(AdapterView<?> parent, final View view, int position, long id) {
     
        				final String itemName = (String) parent.getItemAtPosition(position);
        				
        				//debug toast
        				Toast.makeText(getApplicationContext(), itemName+" selected", Toast.LENGTH_SHORT).show();
        				
        				//fill in the next screen and switch
        				genrateDetScreen(itemName);
        				
        				
        				if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT)        				
        				avw.showNext();
        		}

 		});

        
        
    } // end of displayData()
    
    
    
    
    // Method for filling in the details screen with the selected instance's values in PORT VIEW
    public static  void genrateDetScreen(String carpName)
    {
    	//get the selected carPark from the arraylist
    	int count = -1;
    	count = -1;
    	boolean exit = false;
    	//selected = carParkList.get(0);
    	
    	while (!exit)
    	{
    		count++;
    		if (carParkList.get(count).getName() == carpName)
    		{exit = true;}
    		
    		if (carParkList.size() == count+1)
    		{
    			{exit = true;
    			Log.e("Tom - LOG - ERROR ","overflow"+ Integer.toString(count));
    			}
    		}
    	}
    	/*
    	//fill in text-fields
        textViewS2Name.setText(selected.getName());
        textViewS2Spaces.setText( Integer.toString(selected.getTakenSpaces())+" / "+Integer.toString(selected.getTotalSpaces()));
        textViewS2Occup.setText( Double.toString(selected.calcOccupancy())+"%");
        textViewS2Status.setText(selected.getStatus());
        
        //generate the pie-chart
        int tmpOccup = ((int)selected.calcOccupancy());
        
        String chartURL = "http://chart.apis.google.com/chart?cht=p&chs=250x150&chl=taken|free&chd=t:";
        chartURL += Integer.toString(tmpOccup) + "," + Integer.toString((100-tmpOccup));
        chartURL += "&chco=1c7c78,f9d63e";
        */
        //TODO  do this; http://stackoverflow.com/questions/2471935/how-to-load-an-imageview-by-url-in-android
        
        
        if (isDebugModeON)
        {
        	//Log.e("Tom - LOG",selected.getName());
        	Log.e("Tom - LOG",Integer.toString(carParkList.size()));
        	Log.e("Tom - LOG - GETNAME ",carParkList.get(count).getName());
        	
        	
        	
        	
        	//Log.e("Tom - LOG",chartURL);
        }
    }
    
    

  
  
    //Method for calculating global_OccupiedPlaces
    private static int calc_global_OccupiedPlaces()
    {
    	int count = 0;
    	
    	for(int i=0; i<carParkList.size();i++)
    	{
    		 count = count + carParkList.get(i).getTakenSpaces();  		
    	}
    	
    	return count;
    }
    
    //Method for calculating global_TotalPlaces
    private static int calc_global_TotalPlaces()
    {
    	int count = 0;
    	
    	for(int i=0; i<carParkList.size();i++)
    	{
    		 count = count + carParkList.get(i).getTotalSpaces();		
    	}
    	
    	return count;
    }
     
    //Method to handle button clicks
	public void onClick(View arg0) 
	{
		if (arg0 == backButton)
		{

			avw.showPrevious();
			
		}
		
		if (arg0 == b1)
		{

		
		   // DataUpdater task = new DataUpdater();
		   // task.execute(new String[] { "" });

		}
		
		if (arg0 == b2)
		{
			displayData();
			debudZ();
		}
		
	}
	
	
	//to disable the "built-in" destroy function upon screen rotation, and redraw the elements but skip the data download
	@Override
	public void onConfigurationChanged(Configuration newConfig) {
	    super.onConfigurationChanged(newConfig);

	    // Checks the orientation of the screen
	    if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
	        Toast.makeText(this, "landscape", Toast.LENGTH_SHORT).show();
	    } else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT){
	        Toast.makeText(this, "portrait", Toast.LENGTH_SHORT).show();
	    }
	    
    	//init containers
    	init();
    	
 	
    	//display data
    	displayData();
	}
	
	
	
	
public static void debudZ()
{
	// Toast.makeText(getApplicationContext(), "beep ...", Toast.LENGTH_SHORT).show();
	 Log.e("deb","repetition is on");
}
	
	
	
	
public static void UpdData()
{
    DataUpdater task = new DataUpdater();
    task.execute();
   
}
    


//----------------------------------------------------------------------------------------------------------------



//a method that displays the updated data on the screen
public static void UpdateDispay()
{

	
	//displaying "Global-Total" values
	textViewTotalOccu.setText("Total Occupied Spaces: "+ Integer.toString(calc_global_OccupiedPlaces()));
	textViewTotalTotal.setText("Total Spaces: "+ Integer.toString(calc_global_TotalPlaces()));
	textViewTotalOccup.setText("Total Occupancy: "+ Double.toString(carPark.calcOccupancy(calc_global_OccupiedPlaces(), calc_global_TotalPlaces())));
	
	
//constructing the listview

    
    final ArrayList<String> namelist = new ArrayList<String>();
    
    //building a name-list for the listview
    for (int i = 0; i < carParkList.size(); ++i) 
    {
    	namelist.add(carParkList.get(i).getName());
    }

    //assign the adapter
    final StableArrayAdapter adapter = new StableArrayAdapter(CarParkListingTestActivity.context,android.R.layout.simple_list_item_1,namelist);
    listview.setAdapter(adapter);

    listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {

    		public void onItemClick(AdapterView<?> parent, final View view, int position, long id) {
 
    				String itemName = (String) parent.getItemAtPosition(position);
    				
    				Log.e("DEEB",itemName);
    				
    				//debug toast
    				//Toast.makeText(getApplicationContext(), itemName+" selected", Toast.LENGTH_SHORT).show();
    				
    				//fill in the next screen and switch
    				genrateDetScreen(itemName);
    				
    				
    				if (isOrientPort)        				
    				avw.showNext();
    		}

		});

    //schedule the next data-update
    UpdData();
    
} // end of displayData()




//-------------------------------------------------------------------------------------------------------------
/*
// Handle messages from the Timer Thread
public Handler mainHandler = new Handler()
{
	public void handleMessage(android.os.Message msg)
	{
		// Update UI with new time and progress of progress bar
		if (msg.what == 0)
		{
			
			// Get the formated time
			String data = msg.getData().getString("time");
			// Get the progress for the progress bar
			String progress = msg.getData().getString("progress");
			// Get the colour for the display text
			String colour = msg.getData().getString("colour");
			if (colour.equals("RED"))
			{
				timeDisplay.setTextColor(Color.RED);
			}
			else
			{
				timeDisplay.setTextColor(Color.WHITE);
			}
			// Convert progress to a number
			int intProgress = Integer.parseInt(progress);
			Log.e("MyTag", data);
			Log.e("MyTag", "intProgress is " + intProgress);
			// Display the time as HH:MM:SS
			timeDisplay.setText(data);
			// Update the progress bar
			timerProgress.setProgress(intProgress);
		}
		else
		{
			// Update UI that timer has finished
			if (msg.what == 1)
			{
				startButton.setEnabled(false);
				stopButton.setEnabled(false);
				resetButton.setEnabled(true);
			}
			else					
				{
					Log.e("MyTag", "No Update ");
				}
		}
	}
};
*/

} // End of Activity class










