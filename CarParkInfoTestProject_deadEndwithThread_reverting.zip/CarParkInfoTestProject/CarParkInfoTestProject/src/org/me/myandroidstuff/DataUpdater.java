package org.me.myandroidstuff;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;




import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import android.os.AsyncTask;
import android.os.Handler;
import android.os.SystemClock;
import android.util.Log;


public class DataUpdater extends AsyncTask<String, Void, String> {

	//other variables
	private String sourceListingURL = "http://tomzoy.me/tmp/parking.xml";
	//private String sourceListingURL = "http://open.glasgow.gov.uk/api/live/parking.php?type=xml";

	private boolean isDebugModeON = true;
	private Handler parentHandler; // The handler class to deal with interaction with the parent


	private String result; //string to hold xml data



	@Override
	protected String doInBackground(String... hosta) {

		String response = "";


		//while (CarParkListingTestActivity.isAppRuning == true)
		//{

			try {

				Thread.sleep(20000); //should be 70000 for 70 sec
				response = "suprise!!";
				
				//clear carpark list
				CarParkListingTestActivity.carParkList.clear();
				
				
				readData();

				CarParkListingTestActivity.isUpdated = true;
				Log.e("async","BG done 1");
				
				//CarParkListingTestActivity.this.displayData();
				Thread.sleep(15000); //should be 70000 for 70 sec

			} 

			catch (Exception e) {
				e.printStackTrace();
			}
			Log.e("async","BG done 2");
			CarParkListingTestActivity.debudZ();


			
			
		//}

		return response;

	}



	@Override
	protected void onPostExecute(String result) {
		 Log.e("async","post start");
		 CarParkListingTestActivity.UpdateDispay();
		 Log.e("async","post done");
		
		
	}



	// -------------------------------------------------------------------------------------------------------------------

	private void readData()
	{
		try{
			// Get the data from the RSS stream as a string
			if (isDebugModeON)Log.w("Tom - report","start reading data");
			result =  sourceListingString(sourceListingURL);

			if (isDebugModeON)Log.w("Tom - report","point 1");


			// start parsing data
			XmlPullParserFactory pullParserFactory;
			try {
				pullParserFactory = XmlPullParserFactory.newInstance();
				XmlPullParser parser = pullParserFactory.newPullParser();

				parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);

				parser.setInput(new StringReader ( result ));

				if (isDebugModeON)Log.w("Tom - report","before parser");

				parseXML(parser);
				if (isDebugModeON)Log.w("Tom - report","after parser");

			} catch (XmlPullParserException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}


			if (isDebugModeON)Log.w("Tom - report","parser run with NO exception");


		}
		catch(IOException ae)
		{
			//TODO make this a pop-up
			// Handle error
			//response.setText("Error");

			// Add error info to log for diagnostics


			//errorText.setText(ae.toString());
		}


	};



	// Method to handle the reading of the data from the XML stream
	private static String sourceListingString(String urlString)throws IOException
	{
		String result = "";
		InputStream anInStream = null;
		int response = -1;
		URL url = new URL(urlString);
		URLConnection conn = url.openConnection();

		Log.w("Tom - report","con 1");

		// Check that the connection can be opened
		if (!(conn instanceof HttpURLConnection))
		{
			Log.w("Tom - report","con 2");	
			throw new IOException("Not an HTTP connection");
		}
		try
		{
			// Open connection
			Log.w("Tom - report","con 3");
			HttpURLConnection httpConn = (HttpURLConnection) conn;
			Log.w("Tom - report","con 4");
			httpConn.setAllowUserInteraction(false);
			httpConn.setInstanceFollowRedirects(true);
			httpConn.setRequestProperty("Accept-Charset", "UTF-8");
			Log.w("Tom - report","con 5");
			httpConn.setRequestMethod("GET");
			Log.w("Tom - report","con 6");
			httpConn.connect();
			Log.w("Tom - report","con 7");
			response = httpConn.getResponseCode();
			Log.w("Tom - report","con 8");
			// Check that connection is Ok
			boolean needLine = false;
			Log.w("Tom - report","con 9");
			if (response == HttpURLConnection.HTTP_OK)
			{
				// Connection is Ok so open a reader 
				anInStream = httpConn.getInputStream();
				InputStreamReader in= new InputStreamReader(anInStream,"UTF-8");
				BufferedReader bin= new BufferedReader(in);

				// Read in the data from the XML stream
				String line = new String();

				while (( (line = bin.readLine())) != null)
				{
					if (needLine == true)
						result = result + "\r\n" + line;
					needLine = true;
				}
			}
		}
		catch (Exception ex)
		{
			throw new IOException("Error connecting");
		}

		// Return result as a string for further processing
		return result;

	}





	// Method for parsing the XML data to class instances
	private void parseXML(XmlPullParser parser) throws XmlPullParserException,IOException
	{



		if (isDebugModeON) Log.w("Tom - report","point 3");

		boolean isCarParkIdentityNext = false;
		boolean iscarParkStatusNext = false;
		boolean isoccupiedSpacesNext = false;
		boolean istotalCapacityNext = false;


		String Pname = null;
		int totalSpaces =0;
		int takenSpaces =0;
		String status = null;


		int eventType = parser.getEventType();
		while (eventType != XmlPullParser.END_DOCUMENT) {
			if(eventType == XmlPullParser.START_DOCUMENT) {

				if (isDebugModeON)  Log.w("Tom - report","Start document");

			} else if(eventType == XmlPullParser.START_TAG) {

				if (isDebugModeON) Log.w("Tom - report","Start tag: "+parser.getName());


				if (parser.getName().contains("carParkIdentity"))  
				{	
					isCarParkIdentityNext = true;  //trigger data filed "pull"
				} 


				else if (parser.getName().contains("carParkStatus"))  {	iscarParkStatusNext = true;  } //trigger data filed "pull"
				else if (parser.getName().contains("occupiedSpaces"))  {	isoccupiedSpacesNext = true;  } //trigger data filed "pull"
				else if (parser.getName().contains("totalCapacity"))  {	istotalCapacityNext = true;  }; //trigger data filed "pull"


			} else if(eventType == XmlPullParser.END_TAG) {

				if (isDebugModeON)  Log.w("Tom - report","End tag: "+parser.getName());

			} else if(eventType == XmlPullParser.TEXT) {

				if (isDebugModeON) Log.w("Tom - report","data: "+parser.getText());



				if (isCarParkIdentityNext == true) 
				{
					Log.e("Tom - report","the stuff that I need:"+parser.getText());
					Pname = parser.getText();
					isCarParkIdentityNext = false;
				}

				else if (iscarParkStatusNext == true) 
				{
					Log.e("Tom - report","the stuff that I need:"+parser.getText());
					status = parser.getText();     	 	
					iscarParkStatusNext = false;
				} 

				else if (isoccupiedSpacesNext == true) 
				{
					Log.e("Tom - report","the stuff that I need:"+parser.getText());
					takenSpaces = Integer.parseInt(parser.getText());
					isoccupiedSpacesNext = false;
				}

				else if (istotalCapacityNext == true) 
				{
					Log.e("Tom - report","the stuff that I need:"+parser.getText());
					totalSpaces = Integer.parseInt(parser.getText());
					istotalCapacityNext = false;

					// construct new object
					carPark currentCarPark;
					currentCarPark = new carPark();
					currentCarPark.setName(Pname);
					currentCarPark.trimName();
					currentCarPark.setStatus(status);
					currentCarPark.setTakenSpaces(takenSpaces);
					currentCarPark.setTotalSpaces(totalSpaces);
					CarParkListingTestActivity.carParkList.add(currentCarPark);

					if (isDebugModeON)	Log.e("Tom - report-names","from OBJECT: "+currentCarPark.getName());
					if (isDebugModeON)	Log.e("Tom - report-names","INDEX: "+ CarParkListingTestActivity.carParkList.indexOf(currentCarPark));
					if (isDebugModeON)	Log.e("Tom - report-occu","occu: "+currentCarPark.calcOccupancy());
				};	

			}
			eventType = parser.next();
			if (isDebugModeON)  Log.i("Tom - report","jumpedToNext");
		}


	}


} //end of class
