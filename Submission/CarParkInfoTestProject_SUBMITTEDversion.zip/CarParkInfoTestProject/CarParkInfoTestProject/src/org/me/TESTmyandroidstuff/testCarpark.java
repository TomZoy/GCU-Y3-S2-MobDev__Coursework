/**
 * @author Zoltan Tompa - S1112414
 */
package org.me.TESTmyandroidstuff;

import junit.framework.*;
import org.me.myandroidstuff.carPark;
/**
 * @author TomZoy
 *
 */
public class testCarpark extends TestCase {
	
	

	/**
	 * Test method for {@link org.me.myandroidstuff.carPark#calcOccupancy()}.
	 */
	public void testCalcOccupancy() {
		


		int input[] = new int[] {10,0,0,0,0,10,5,10,70,80 };
		double expected[]  = new double[] {0.0,0.0,0.0,50.0,87.5};
		double temp;
		for (int i = 0; i< expected.length;i++ )
		{
			temp = carPark.calcOccupancy(input[i],input[i+1]);
			assertEquals("test failed: ", expected[i], temp);
		}
	}



	
	 // Test method for {@link org.me.myandroidstuff.carPark#trimName()}.
	 
	public void testTrimName() {
		carPark testInstance1 = new carPark();
		
		String input[] = new String[] {"123456789","abc","1234567","" };
		String expected[]  = new String[] {"12","abc","1234567",""};
		for (int i = 0; i< expected.length;i++ )
		{
			testInstance1.setName(input[i]);
			assertEquals("test failed: ", expected[i],testInstance1.getName());
		}
	}

}
