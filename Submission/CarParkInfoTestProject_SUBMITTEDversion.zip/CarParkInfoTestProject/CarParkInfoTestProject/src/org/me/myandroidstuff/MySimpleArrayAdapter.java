/**
 * @author Zoltan Tompa - S1112414
 * refference: http://www.vogella.com/tutorials/AndroidListView/article.html
 */
package org.me.myandroidstuff;


import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;


public class MySimpleArrayAdapter extends ArrayAdapter<String> {
	  private final Context context;
	  private final List<String> names;
	  private final List<Integer> values;

	  public MySimpleArrayAdapter(Context context, List<String> names, List<Integer> values) {
	    super(context, R.layout.row, names);
	    this.context = context;
	    this.names = names;
	    this.values = values;
	  }

	  @Override
	  public View getView(int position, View convertView, ViewGroup parent) {
	    LayoutInflater inflater = (LayoutInflater) context
	        .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	    View rowView = inflater.inflate(R.layout.row, parent, false);
	    TextView textView = (TextView) rowView.findViewById(R.id.listText);
	    ImageView imageView = (ImageView) rowView.findViewById(R.id.icon);
	    textView.setText(names.get(position));
	    // change the icon for Windows and iPhone
	    int s = values.get(position);
	    if (s == 0) {
	      imageView.setImageResource(R.drawable.red);
	    } 
	    
	    else if (s==1){
	      imageView.setImageResource(R.drawable.orange);
	    }
	    else 
	    {
	    	imageView.setImageResource(R.drawable.green);
	    }

	    return rowView;
	  }
	} 


