I've also included the report here, but I'll submit a hardcopy on Monday 9th March as well.

The video is also accessible from here: https://www.youtube.com/watch?v=EU5km3lkEhY&feature=youtu.be

Also the current code sometimes struggles to connect to the feed, and that can be fixed by changing the manifest file's min APK version to "9". This should be patched up in the final version.

Thank you for understanding,
Zoltan Tompa