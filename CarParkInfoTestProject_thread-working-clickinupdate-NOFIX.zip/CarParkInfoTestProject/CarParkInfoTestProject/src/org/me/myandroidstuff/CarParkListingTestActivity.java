package org.me.myandroidstuff;


import java.util.ArrayList;

import android.app.Activity;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewSwitcher;




public class CarParkListingTestActivity extends Activity implements OnClickListener 
{

	//variables bound to GUI
	private Button backButton;
	//private TextView response;
	private TextView errorText;
	private TextView textViewTotalOccu;
	private TextView textViewTotalTotal;
	private TextView textViewTotalOccup;
	private TextView textViewS2Name;
	private TextView textViewS2Spaces;
	private TextView textViewS2Occup;
	private TextView textViewS2Status;
	private ImageView pieChart;
	
	private ViewSwitcher avw;
	


	public static ArrayList<carPark> carParkList1 = new ArrayList<carPark>(); // a list to store the carPark instances 1
    public static ArrayList<carPark> carParkList2 = new ArrayList<carPark>(); // a list to store the carPark instances 1
    
    public static ArrayList<ArrayList<carPark>> carParkListArray = new ArrayList<ArrayList<carPark>>();
    public int currentCarParkList;
    
    private UpdaterThread myThread;
    

	
    private boolean isDebugModeON = true;
    private boolean isFirtsRun = false;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) 
    {
    	
    	if (isDebugModeON) Log.w("Tom - report","appstart test");
    	
        super.onCreate(savedInstanceState);

        	//init containers
        	init();
        	
        	//read data
        	startUpdater();
        	

        	


        
    } // End of onCreate
    
    private void init()
    {
    	//myThread = new UpdaterThread(mainHandler);
    	//myThread.start();
    	
        setContentView(R.layout.main);
        
        //set up viewSwitcher
        avw = (ViewSwitcher) findViewById(R.id.vwSwitch);
        
        // Get the View object on which to display the results

        //TODO sort this out
        errorText = (TextView)findViewById(R.id.author);
        
        textViewTotalOccu = (TextView)findViewById(R.id.textViewTotalOccu);
        textViewTotalTotal = (TextView)findViewById(R.id.textViewTotalTotal);
        textViewTotalOccup = (TextView)findViewById(R.id.textViewTotalOccup);
        
        textViewS2Name = (TextView)findViewById(R.id.Parkname);
        textViewS2Spaces = (TextView)findViewById(R.id.S2Spaces);
        textViewS2Occup = (TextView)findViewById(R.id.S2Occup);
        textViewS2Status = (TextView)findViewById(R.id.S2Status);
        
        pieChart = (ImageView)findViewById(R.id.PChart);
        
        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT)        				
        {
	        backButton= (Button) findViewById(R.id.s2backbutton);
	        backButton.setOnClickListener(this);
        }
        
        carParkListArray.add(carParkList1);
        carParkListArray.add(carParkList2);
        currentCarParkList = 0;
    	
    }
    
    //****************************************************
    
    
	// Handle messages from the Timer Thread
	public Handler mainHandler = new Handler() 
	{
		public void handleMessage(android.os.Message msg)
		{
			// Update UI with new time and progress of progress bar
			if (msg.what == 0)
			{
				currentCarParkList = msg.getData().getInt("currentCarParkList");
				///*currentCarParkList
	        	//display data
				Log.e("Ztag","disp. data invoked");
				Log.e("Z",Integer.toString(currentCarParkList));
	        	displayData();

	        	if (isDebugModeON)Log.e("Tom - report","program run DONE");

			}
			else
			{
			
			}
				

		}
	};
    

    //**********************************************************
    
	public void startUpdater()
	{
	// Send initial time

				// Start the thread
				myThread = new UpdaterThread(mainHandler);
				myThread.start();
				

					// Send start message to timer class
					Bundle abundle = new Bundle();
					//*abundle.putInt("timerCount",value);
					Message messageToThread = new Message();				
					messageToThread.what = 0;
					messageToThread.setData(abundle);
					myThread.getHandler().sendMessage(messageToThread);

	
	}
//**********************************************    
    private void displayData()
    {
    	//displaying "Global-Total" values
    	textViewTotalOccu.setText("Total Occupied Spaces: "+ Integer.toString(calc_global_OccupiedPlaces()));
    	textViewTotalTotal.setText("Total Spaces: "+ Integer.toString(calc_global_TotalPlaces()));
    	textViewTotalOccup.setText("Total Occupancy: "+ Double.toString(carPark.calcOccupancy(calc_global_OccupiedPlaces(), calc_global_TotalPlaces()))+"%");
    	
    	
    //constructing the listview

        final ListView listview = (ListView) findViewById(R.id.listview);
        final ArrayList<String> namelist = new ArrayList<String>();
        
        //building a name-list for the listview
        for (int i = 0; i < carParkListArray.get(currentCarParkList).size(); ++i) 
        {
        	namelist.add((carParkListArray.get(currentCarParkList).get(i)).getName());
        }
 
        //assign the adapter
        final StableArrayAdapter adapter = new StableArrayAdapter(this,android.R.layout.simple_list_item_1,namelist);
        listview.setAdapter(adapter);

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {

        		public void onItemClick(AdapterView<?> parent, final View view, int position, long id) {
     
        				final String itemName = (String) parent.getItemAtPosition(position);
        				
        				//debug toast
        				Toast.makeText(getApplicationContext(), itemName+" selected", Toast.LENGTH_SHORT).show();
        				
        				//fill in the next screen and switch
        				genrateDetScreen(itemName);
        				
        				
        				if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT)        				
        				avw.showNext();
        		}

 		});

        
        
    } // end of displayData()
    
    // Method for filling in the details screen with the selected instance's values in PORT VIEW
    public void genrateDetScreen(String carpName)
    {
    	//get the selected carPark from the arraylist
    	int count = 0;
    	carPark selected = new carPark(); 	
    	selected = carParkList1.get(0);
    	while (selected.getName()!=carpName)
    	{
    		count++;
    		selected = carParkList1.get(count);
    	}
    	
    	//fill in text-fields
        textViewS2Name.setText(selected.getName());
        textViewS2Spaces.setText( Integer.toString(selected.getTakenSpaces())+" / "+Integer.toString(selected.getTotalSpaces()));
        textViewS2Occup.setText( Double.toString(selected.calcOccupancy())+"%");
        textViewS2Status.setText(selected.getStatus());
        
        //generate the pie-chart
        int tmpOccup = ((int)selected.calcOccupancy());
        
        String chartURL = "http://chart.apis.google.com/chart?cht=p&chs=250x150&chl=taken|free&chd=t:";
        chartURL += Integer.toString(tmpOccup) + "," + Integer.toString((100-tmpOccup));
        chartURL += "&chco=1c7c78,f9d63e";
        
        //TODO  do this; http://stackoverflow.com/questions/2471935/how-to-load-an-imageview-by-url-in-android
        
        if (isDebugModeON)
        {
        	Log.e("Tom - LOG",selected.getName());
        	Log.e("Tom - LOG",chartURL);
        }
    }
    
    
    
  
    //Method for calculating global_OccupiedPlaces
    public int calc_global_OccupiedPlaces()
    {
    	int count = 0;
    	
    	for(int i=0; i<carParkList1.size();i++)
    	{
    		 count = count + carParkList1.get(i).getTakenSpaces();  		
    	}
    	
    	return count;
    }
    
    //Method for calculating global_TotalPlaces
    public int calc_global_TotalPlaces()
    {
    	int count = 0;
    	
    	for(int i=0; i<carParkList1.size();i++)
    	{
    		 count = count + carParkList1.get(i).getTotalSpaces();		
    	}
    	
    	return count;
    }
     
    //Method to handle button clicks
	public void onClick(View arg0) 
	{
		if (arg0 == backButton)
		{
			avw.showPrevious();
		}
	}
	
	
	//to disable the "built-in" destroy function upon screen rotation, and redraw the elements but skip the data download
	@Override
	public void onConfigurationChanged(Configuration newConfig) {
	    super.onConfigurationChanged(newConfig);

	    // Checks the orientation of the screen
	    if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
	        Toast.makeText(this, "landscape", Toast.LENGTH_SHORT).show();
	    } else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT){
	        Toast.makeText(this, "portrait", Toast.LENGTH_SHORT).show();
	    }
	    
    	//init containers
    	init();
    	
 	
    	//display data
    	displayData();
	}
	
	
	
	
	
    
} // End of Activity class