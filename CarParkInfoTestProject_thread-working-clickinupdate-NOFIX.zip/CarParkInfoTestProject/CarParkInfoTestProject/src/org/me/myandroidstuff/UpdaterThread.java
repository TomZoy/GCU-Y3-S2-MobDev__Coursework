package org.me.myandroidstuff;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;


public class UpdaterThread extends Thread{


	private boolean updateRunning;   // The "updateRunning" status of the counter

	//private String time;
	private Handler parentHandler; // The handler class to deal with interaction with the parent

	private boolean isDebugModeON;
	private String result; //string to hold xml data
	
	//other variables
	private String sourceListingURL = "http://tomzoy.me/tmp/parking.xml";
	//private String sourceListingURL = "http://open.glasgow.gov.uk/api/live/parking.php?type=xml";
	
	private int updateIntervall = 15000;
	
	private int currentCarParkList;
	
	public UpdaterThread() {

		updateRunning = false;

	}
	
	
	public UpdaterThread(Handler parentHandler) {

		this.parentHandler = parentHandler;
		updateRunning = false;

	}
	

	//*********************************************************
	

	
	private Handler myThreadHandler = new Handler()
	{
		// Handle messages from the parent
		public void handleMessage(Message msg)
		{
			
			if (msg.what == 0)
			{				
				updateRunning = true;
			}
			
			else
			{
				updateRunning = false;
			}
	}
	};
	
	public Handler getHandler()
	{
		return myThreadHandler;
	}
	
	//
	// This is where the main work of the class is done
	// 
	public void run()
	{
		
		super.run();
		
		isDebugModeON = true;
		currentCarParkList = 0;

		
		try
		{
			while(true)			
			{
				
				readData();
				
				if (updateRunning == true)
				{
					Log.e("Z","readDataStarted");
					readData();
					Log.e("Z","readData DONE");
				}
				else
				{
					Log.e("Z"," else path reached");
					Log.e("Z"," M 1");
					Message messageToParent = new Message();
					Log.e("Z"," M 2");
					Bundle messageData = new Bundle();
					Log.e("Z"," M 3");
					messageToParent.what = 0;
					Log.e("Z"," M 4");
					messageData.putInt("currentCarParkList", currentCarParkList);

					// Package Data and send it
					messageToParent.setData(messageData);
					Log.e("Z"," M 5");
					parentHandler.sendMessage(messageToParent);
					Log.e("Z"," M 6");
				}
				
				currentCarParkList ++;
				if (currentCarParkList ==2) {currentCarParkList=0;}
				sleep(updateIntervall);
			} // End of while
		}
		catch (Exception ae)
		{
			Log.e("MyTag","Time loop exception");
		}
		
	} // End of run
	


	//-------------------------------------------------------------------------------------------------
	
    private void readData()
    {
    	try{
    	// Get the data from the RSS stream as a string
    	if (isDebugModeON)Log.w("Tom - report","start reading data");
    	result =  sourceListingString(sourceListingURL);
    	
    	if (isDebugModeON)Log.w("Tom - report","point 1");

   	
    	// start parsing data
    	XmlPullParserFactory pullParserFactory;
		try {
			pullParserFactory = XmlPullParserFactory.newInstance();
			XmlPullParser parser = pullParserFactory.newPullParser();

		        parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
		        
		        parser.setInput(new StringReader ( result ));
		        
		        if (isDebugModeON)Log.w("Tom - report","before parser");
	            
		        parseXML(parser);
		        if (isDebugModeON)Log.w("Tom - report","after parser");

		} catch (XmlPullParserException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		
		if (isDebugModeON)Log.w("Tom - report","parser run with NO exception");
		

		if (isDebugModeON){
       /* 	Log.e("Tom - report -List","Total carparks: "+ Integer.toString(CarParkListingTestActivity.carParkList1.size()));
        	Log.e("Tom - report -List","Total Occupied Spaces: "+ Integer.toString(CarParkListingTestActivity.calc_global_OccupiedPlaces()));
        	Log.e("Tom - report -List","Total Spaces: "+ Integer.toString(CarParkListingTestActivity.calc_global_TotalPlaces()));
    	
    	Log.e("Tom - report -List","Total Occupancy: "+ Double.toString(carPark.calcOccupancy(CarParkListingTestActivity.calc_global_OccupiedPlaces(), calc_global_TotalPlaces())));
		*/
		}
    	}
        catch(IOException ae)
        {
        	//TODO make this a pop-up

        }
    	
    	updateRunning = false;

    	
    }

    // Method to handle the reading of the data from the XML stream
    private static String sourceListingString(String urlString)throws IOException
    {
	 	String result = "";
    	InputStream anInStream = null;
    	int response = -1;
    	URL url = new URL(urlString);
    	URLConnection conn = url.openConnection();
    	
    	Log.w("Tom - report","con 1");
    	
    	// Check that the connection can be opened
    	if (!(conn instanceof HttpURLConnection))
    	{
			Log.w("Tom - report","con 2");	
    		throw new IOException("Not an HTTP connection");
    	}
    	try
    	{
    		// Open connection
    		Log.w("Tom - report","con 3");
    		HttpURLConnection httpConn = (HttpURLConnection) conn;
    		Log.w("Tom - report","con 4");
    		httpConn.setAllowUserInteraction(false);
    		httpConn.setInstanceFollowRedirects(true);
    		httpConn.setRequestProperty("Accept-Charset", "UTF-8");
    		Log.w("Tom - report","con 5");
    		httpConn.setRequestMethod("GET");
    		Log.w("Tom - report","con 6");
    		httpConn.connect();
    		Log.w("Tom - report","con 7");
    		response = httpConn.getResponseCode();
    		Log.w("Tom - report","con 8");
    		// Check that connection is Ok
			boolean needLine = false;
			Log.w("Tom - report","con 9");
    		if (response == HttpURLConnection.HTTP_OK)
    		{
    			// Connection is Ok so open a reader 
    			anInStream = httpConn.getInputStream();
    			InputStreamReader in= new InputStreamReader(anInStream,"UTF-8");
    			BufferedReader bin= new BufferedReader(in);
    			
    			// Read in the data from the XML stream
    			String line = new String();

    			while (( (line = bin.readLine())) != null)
    			{
    				if (needLine == true)
    				result = result + "\r\n" + line;
    				needLine = true;
    			}
    		}
    	}
    	catch (Exception ex)
    	{
    			throw new IOException("Error connecting");
    	}
    	
    	// Return result as a string for further processing
    	return result;
    	
    }
    
      
    // Method for parsing the XML data to class instances
    private void parseXML(XmlPullParser parser) throws XmlPullParserException,IOException
	{

    	

    	if (isDebugModeON) Log.w("Tom - report","point 3");
        
        boolean isCarParkIdentityNext = false;
        boolean iscarParkStatusNext = false;
        boolean isoccupiedSpacesNext = false;
        boolean istotalCapacityNext = false;
        
        
    	 String Pname = null;
    	 int totalSpaces =0;
    	 int takenSpaces =0;
    	 String status = null;
        
        int eventType = parser.getEventType();
        
        CarParkListingTestActivity.carParkListArray.get(currentCarParkList).clear();
        
        
        while (eventType != XmlPullParser.END_DOCUMENT) {
         if(eventType == XmlPullParser.START_DOCUMENT) {
           
        	 if (isDebugModeON)  Log.w("Tom - report","Start document");
             
         } else if(eventType == XmlPullParser.START_TAG) {

        	 if (isDebugModeON) Log.w("Tom - report","Start tag: "+parser.getName());
            
             
             if (parser.getName().contains("carParkIdentity"))  
             {	
            	 isCarParkIdentityNext = true;  //trigger data filed "pull"
              } 
             
             
             else if (parser.getName().contains("carParkStatus"))  {	iscarParkStatusNext = true;  } //trigger data filed "pull"
             else if (parser.getName().contains("occupiedSpaces"))  {	isoccupiedSpacesNext = true;  } //trigger data filed "pull"
             else if (parser.getName().contains("totalCapacity"))  {	istotalCapacityNext = true;  }; //trigger data filed "pull"
             
  
         } else if(eventType == XmlPullParser.END_TAG) {

        	 if (isDebugModeON)  Log.w("Tom - report","End tag: "+parser.getName());
             
         } else if(eventType == XmlPullParser.TEXT) {

        	 if (isDebugModeON) Log.w("Tom - report","data: "+parser.getText());
             

            	
             if (isCarParkIdentityNext == true) 
        	 {
        	 	Log.e("Tom - report","the stuff that I need:"+parser.getText());
        	 	Pname = parser.getText();
        	 	isCarParkIdentityNext = false;
        	 }
            	 
        	 else if (iscarParkStatusNext == true) 
        	 {
        	 	Log.e("Tom - report","the stuff that I need:"+parser.getText());
        	 	status = parser.getText();     	 	
        	 	iscarParkStatusNext = false;
        	 } 
            	 
        	 else if (isoccupiedSpacesNext == true) 
        	 {
        	 	Log.e("Tom - report","the stuff that I need:"+parser.getText());
        	 	takenSpaces = Integer.parseInt(parser.getText());
        	 	isoccupiedSpacesNext = false;
        	 }
        	 
        	 else if (istotalCapacityNext == true) 
        	 {
        	 	Log.e("Tom - report","the stuff that I need:"+parser.getText());
        	 	totalSpaces = Integer.parseInt(parser.getText());
        	 	istotalCapacityNext = false;
        	 	
        	 	// construct new object
        	 	carPark currentCarPark;
        	 	currentCarPark = new carPark();
        	 	currentCarPark.setName(Pname);
        	 		currentCarPark.trimName();
        	 	currentCarPark.setStatus(status);
        	 	currentCarPark.setTakenSpaces(takenSpaces);
        	 	currentCarPark.setTotalSpaces(totalSpaces);
        	 	CarParkListingTestActivity.carParkListArray.get(currentCarParkList).add(currentCarPark);
        	 	
        	 	if (isDebugModeON)	Log.e("Tom - report-names","from OBJECT: "+currentCarPark.getName());
        	 	if (isDebugModeON)	Log.e("Tom - report-occu","occu: "+currentCarPark.calcOccupancy());
        	 };	
 	 
         }
         eventType = parser.next();
         if (isDebugModeON)  Log.i("Tom - report","jumpedToNext");
        }
 
        
	}
}
