/**
 * Zoltan Tompa - S1112414
 */
package org.me.myandroidstuff;
import java.lang.Math;


/**
 * @author Zoltan Tompa
 *
 */
public class carPark {


	
	private String id;
	private String name;
	private int totalSpaces;
	private int takenSpaces;
	private String status;
	
	
	public carPark() {
		// TODO Auto-generated constructor stub
	}
	
	//method to do in-class occupancy calculation
	public double calcOccupancy()
	{
		double occu = (((double)takenSpaces) / totalSpaces); //getting a precentige (0-1)
		occu = Math.round(occu *100*100.0)/100.0; //making it a precentige 0-100 and rounding it to two decimals
		return occu;		
	}
	
	//method to do general occupancy calculation
	public static double calcOccupancy(int taken, int total)
	{
		double occu = (((double)taken) / total); //getting a precentige (0-1)
		occu = Math.round(occu *100*100.0)/100.0; //making it a precentige 0-100 and rounding it to two decimals
		return occu;		
	}

	public void trimName()
	{
		name = name.substring(0, name.length()-7); 
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}


	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}


	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}


	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}


	/**
	 * @return the totalSpaces
	 */
	public int getTotalSpaces() {
		return totalSpaces;
	}


	/**
	 * @param totalSpaces the totalSpaces to set
	 */
	public void setTotalSpaces(int totalSpaces) {
		this.totalSpaces = totalSpaces;
	}


	/**
	 * @return the takenSpaces
	 */
	public int getTakenSpaces() {
		return takenSpaces;
	}


	/**
	 * @param takenSpaces the takenSpaces to set
	 */
	public void setTakenSpaces(int takenSpaces) {
		this.takenSpaces = takenSpaces;
	}


	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}


	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

}
